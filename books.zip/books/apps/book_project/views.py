# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from .models import bookdb

# Create your views here.
def index(request):
    bookdb.objects.create(title="Harry Potter",author="JK", published_date="09/2017",category="fiction")
    book = bookdb.objects.all()
    print (book)
    return render (request, "book_project/index.html")
