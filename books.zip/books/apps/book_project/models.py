# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class bookdb(models.Model):
    title= models.CharField(max_length=38)
    author= models.CharField(max_length=38)
    published_date= models.CharField(max_length=38)
    category= models.CharField(max_length=38)
